# 🚀 Instagram Assistant Proxy - OpenAPI Schema

هذا الملف يجهّز سكيمة OpenAPI كاملة لدمج خادمك مع ChatGPT Actions.

## 📂 محتويات
- `openapi.json` → سكيمة OpenAPI فيها جميع الـ Routes (status, publish, insights, best-time).
- `README.md` → هذا الملف يشرح طريقة الاستخدام.

## ⚙️ خطوات الاستخدام
1. ارفع الملف `openapi.json` على مشروعك (جذر Vercel).
2. افتح الرابط: `https://YOUR_DOMAIN.vercel.app/openapi.json` وتأكد أنه يظهر.
3. في [ChatGPT GPT Builder](https://chat.openai.com/gpts/editor):
   - اذهب إلى **Actions**.
   - اختر **Import schema from URL**.
   - ضع رابط `openapi.json`.
4. أضف Authentication:
   - النوع: **API Key (Header)**.
   - الاسم: `x-api-key`.
   - القيمة: نفس السر المخزّن عندك في Vercel.

## 🧪 اختبار
اطلب من GPT مثلًا:
- "انشر صورة على إنستغرام" → يستدعي `/instagram/publish`.
- "أعطني إنسايتس الحساب" → يستدعي `/instagram/insights/account`.
- "متى أفضل وقت للنشر؟" → يستدعي `/instagram/best-time`.

---
✨ بهذا تكون جاهز للدمج المباشر بين ChatGPT وإنستغرام عبر خادمك.
