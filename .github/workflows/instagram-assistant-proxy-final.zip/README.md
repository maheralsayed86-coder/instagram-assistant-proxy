# 🚀 Instagram Assistant Proxy

Proxy مبني على Vercel مع حماية باستخدام API Key + دعم Instagram Graph API.

## 📂 Routes
- `/api/status` → فحص حالة السيرفر.
- `/api/proxy` → تمرير طلبات لأي API خارجي.
- `/api/instagram` → جلب معلومات الحساب من Instagram Graph API.

## 🔒 الحماية
كل طلب لازم يحتوي Header:
```
x-api-key: YOUR_SECRET
```

## ⚙️ الإعداد في Vercel
1. أضف متغير البيئة:
   - `API_SECRET=your-secret-key`
   - `INSTAGRAM_ACCESS_TOKEN=your-instagram-token`
2. اعمل Redeploy للمشروع.

## 🧪 اختبار عبر cURL
```
curl -H "x-api-key: YOUR_SECRET" https://your-app.vercel.app/api/status
curl -H "x-api-key: YOUR_SECRET" https://your-app.vercel.app/api/instagram
```

---
✍️ لاحقاً تقدر توسع المشروع ليدعم: جدولة نشر البوستات، إدارة التعليقات، أو أي API آخر.
