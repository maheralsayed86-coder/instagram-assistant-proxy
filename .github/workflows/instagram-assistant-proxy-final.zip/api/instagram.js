export default async function handler(req, res) {
  const apiKey = req.headers["x-api-key"];
  if (!apiKey || apiKey !== process.env.API_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const accessToken = process.env.INSTAGRAM_ACCESS_TOKEN;
  if (!accessToken) {
    return res.status(500).json({ error: "Missing Instagram Access Token" });
  }

  try {
    const url = `https://graph.instagram.com/me?fields=id,username,account_type,media_count&access_token=${accessToken}`;

    const response = await fetch(url);
    const data = await response.json();

    if (data.error) {
      return res.status(500).json({ error: "Instagram API Error", details: data.error });
    }

    res.status(200).json({ profile: data });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch from Instagram API", details: err.message });
  }
}
