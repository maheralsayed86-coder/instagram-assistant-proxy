export default function handler(req, res) {
  const apiKey = req.headers["x-api-key"];
  if (!apiKey || apiKey !== process.env.API_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  res.status(200).json({
    status: "ok",
    message: "✅ Status route is working!",
    timestamp: new Date().toISOString(),
  });
}
