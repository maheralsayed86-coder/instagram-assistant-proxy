# 📌 Instagram Assistant Proxy

خادم Node.js صغير يعمل عبر Vercel لتشغيل إنستقرام API بشكل آمن وربطه مع GPT Actions.

## 🚀 Routes
- `GET /api/status` ✅ للتحقق من عمل السيرفر
- `POST /api/publish` 📤 لنشر صورة/فيديو مع Caption
- `GET /api/insights/account` 📊 إحصائيات الحساب
- `GET /api/insights/media?media_id=xxx` 📊 إحصائيات بوست معين
- `GET /api/best-time` ⏰ أوقات النشر المقترحة

## ⚙️ الإعداد
1. انسخ `.env.example` إلى `.env`
2. أضف القيم:
   - `API_SECRET`
   - `IG_ACCESS_TOKEN`
   - `DEFAULT_IG_USER_ID`
3. ارفع المشروع على Vercel
4. استورد `openapi.json` في GPT Builder

