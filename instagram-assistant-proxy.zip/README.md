# 🚀 Instagram Assistant Proxy

Proxy بسيط مبني على Vercel مع حماية باستخدام API Key.

## Routes
- `/api/status` → فحص السيرفر.
- `/api/login` → تسجيل دخول تجريبي.
- `/api/proxy` → تمرير طلبات لأي API.
- `/api/instagram?action=profile|posts` → محاكاة أوامر Instagram.

## الحماية
كل طلب لازم يحتوي Header:
```
x-api-key: your-secret-key
```

## الإعداد
1. أضف متغير البيئة في Vercel:
```
API_SECRET=your-secret-key
```
2. ارفع المشروع على GitHub واربطه مع Vercel.
3. اعمل Deploy واستمتع 🎉.
