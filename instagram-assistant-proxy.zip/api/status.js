import { checkAuth } from "../utils/auth.js";

export default function handler(req, res) {
  if (!checkAuth(req, res)) return;

  res.status(200).json({
    status: "✅ Server is healthy",
    uptime: process.uptime(),
  });
}
