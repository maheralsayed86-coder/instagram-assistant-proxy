import fetch from "node-fetch";

export default async function handler(req, res) {
  const apiKey = req.headers["x-api-key"];
  if (!apiKey || apiKey !== process.env.API_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { image_url, caption } = req.body;
    if (!image_url || !caption) {
      return res.status(400).json({ error: "Missing image_url or caption" });
    }

    const createContainer = await fetch(
      `https://graph.facebook.com/v17.0/${process.env.DEFAULT_IG_USER_ID}/media?image_url=${encodeURIComponent(image_url)}&caption=${encodeURIComponent(caption)}&access_token=${process.env.IG_ACCESS_TOKEN}`,
      { method: "POST" }
    );
    const containerData = await createContainer.json();

    if (containerData.error) {
      return res.status(400).json({ error: containerData.error });
    }

    const publishMedia = await fetch(
      `https://graph.facebook.com/v17.0/${process.env.DEFAULT_IG_USER_ID}/media_publish?creation_id=${containerData.id}&access_token=${process.env.IG_ACCESS_TOKEN}`,
      { method: "POST" }
    );
    const publishData = await publishMedia.json();

    res.status(200).json({ success: true, result: publishData });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
