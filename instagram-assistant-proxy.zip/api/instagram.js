import { checkAuth } from "../utils/auth.js";

export default function handler(req, res) {
  if (!checkAuth(req, res)) return;

  const { action } = req.query;

  if (action === "profile") {
    return res.status(200).json({ profile: "👤 Mock Instagram Profile" });
  }

  if (action === "posts") {
    return res.status(200).json({ posts: ["post1", "post2", "post3"] });
  }

  res.status(400).json({ error: "Invalid action" });
}
