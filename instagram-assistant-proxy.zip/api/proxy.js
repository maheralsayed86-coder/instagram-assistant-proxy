import { checkAuth } from "../utils/auth.js";

export default async function handler(req, res) {
  if (!checkAuth(req, res)) return;

  const { url, method, body } = req.body;

  if (!url) {
    return res.status(400).json({ error: "Missing 'url' in request body" });
  }

  try {
    const response = await fetch(url, {
      method: method || "GET",
      headers: { "Content-Type": "application/json" },
      body: method === "POST" ? JSON.stringify(body) : undefined,
    });

    const data = await response.json();
    res.status(200).json({ success: true, data });
  } catch (error) {
    res.status(500).json({ error: "Proxy request failed", details: error.message });
  }
}
