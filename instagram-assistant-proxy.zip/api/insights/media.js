import fetch from "node-fetch";

export default async function handler(req, res) {
  const apiKey = req.headers["x-api-key"];
  if (!apiKey || apiKey !== process.env.API_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  const { media_id } = req.query;
  if (!media_id) {
    return res.status(400).json({ error: "Missing media_id" });
  }

  try {
    const resp = await fetch(
      `https://graph.facebook.com/v17.0/${media_id}/insights?metric=impressions,reach,engagement&access_token=${process.env.IG_ACCESS_TOKEN}`
    );
    const data = await resp.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
