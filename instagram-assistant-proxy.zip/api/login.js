import { checkAuth } from "../utils/auth.js";

export default function handler(req, res) {
  if (!checkAuth(req, res)) return;

  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { username, password } = req.body;

  // Mock login - لاحقاً نربطه مع Instagram API أو DB
  res.status(200).json({
    message: "🔑 Login success (mocked)",
    user: username,
  });
}
