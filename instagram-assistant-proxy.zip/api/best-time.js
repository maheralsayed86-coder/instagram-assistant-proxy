export default function handler(req, res) {
  const apiKey = req.headers["x-api-key"];
  if (!apiKey || apiKey !== process.env.API_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  res.status(200).json({
    best_times: [
      "2025-09-29T10:00:00Z",
      "2025-09-29T18:00:00Z",
      "2025-09-30T12:00:00Z"
    ]
  });
}
